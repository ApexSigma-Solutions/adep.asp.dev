# Now create the relationships (edges) between all these entities

print("Creating relationships between entities...")

# Organization relationships
create_edge(sigmaDev11_id, apexsigma_org_id, "FOUNDED", {"role": "Founder", "year": "2025"})
create_edge(sigmaDev11_id, apexsigma_org_id, "LEADS", {"authority": "Supreme decision authority"})

# Agent hierarchy relationships
create_edge(gemini_id, sigmaDev11_id, "REPORTS_TO", {"tier": "2", "relationship_type": "Quality & Strategic Review"})
create_edge(gemini_cli_id, gemini_id, "REPORTS_TO", {"tier": "3", "relationship_type": "Implementation Specialist"})
create_edge(gemini_cli_id, sigmaDev11_id, "REPORTS_TO", {"tier": "3", "escalation": True})
create_edge(qwen_id, gemini_id, "REPORTS_TO", {"tier": "3", "relationship_type": "Implementation Specialist"})
create_edge(qwen_id, sigmaDev11_id, "REPORTS_TO", {"tier": "3", "escalation": True})

# Service relationships
create_edge(memos_id, apexsigma_org_id, "BELONGS_TO", {"category": "Core Service"})
create_edge(ingest_llm_id, apexsigma_org_id, "BELONGS_TO", {"category": "Core Service"})
create_edge(devenviro_id, apexsigma_org_id, "BELONGS_TO", {"category": "Core Service"})
create_edge(tools_id, apexsigma_org_id, "BELONGS_TO", {"category": "Core Service"})

# Protocol relationships
create_edge(omega_ingest_laws_id, apexsigma_org_id, "GOVERNS", {"scope": "Knowledge Graph Management"})
create_edge(mar_protocol_id, apexsigma_org_id, "GOVERNS", {"scope": "Quality Assurance"})
create_edge(taskmaster_protocol_id, apexsigma_org_id, "GOVERNS", {"scope": "Task Orchestration"})

# Protocol enforcement relationships
create_edge(gemini_id, mar_protocol_id, "ENFORCES", {"role": "Guardian of MAR Protocol"})
create_edge(gemini_id, omega_ingest_laws_id, "ENFORCES", {"verification_tier": "1-3"})
create_edge(sigmaDev11_id, taskmaster_protocol_id, "OWNS", {"role": "Framework Owner"})

# Infrastructure relationships  
create_edge(neo4j_id, omega_ingest_laws_id, "IMPLEMENTS", {"role": "Master Knowledge Graph Storage"})
create_edge(neo4j_id, memos_id, "SUPPORTS", {"tier": "4", "memory_type": "episodic"})
create_edge(postgresql_id, memos_id, "SUPPORTS", {"tier": "2", "memory_type": "procedural"})

# Service integration relationships
create_edge(ingest_llm_id, neo4j_id, "FEEDS_DATA_TO", {"role": "Ingestion Gateway"})
create_edge(ingest_llm_id, memos_id, "INTEGRATES_WITH", {"api_integration": True})

# Project relationships
create_edge(monorepo_genesis_id, apexsigma_org_id, "TRANSFORMS", {"completion_date": "2025-09-13"})
create_edge(asgard_rebirth_id, memos_id, "UPGRADES", {"target": "MCP Integration"})
create_edge(adep_sprint1_id, asgardian_forge_id, "IMPLEMENTS", {"phase": "Phase 1"})
create_edge(asgardian_forge_id, apexsigma_org_id, "TRANSFORMS", {"goal": "Autonomous Development Ecosystem"})

# Agent assignment relationships
create_edge(gemini_cli_id, adep_sprint1_id, "IMPLEMENTS", {"role": "Primary Implementor"})
create_edge(gemini_id, adep_sprint1_id, "REVIEWS", {"role": "Primary Reviewer"})
create_edge(qwen_id, adep_sprint1_id, "IMPLEMENTS", {"role": "Specialized Implementor"})

create_edge(gemini_cli_id, asgard_rebirth_id, "IMPLEMENTS", {"phases": ["P1", "P2", "P3"]})
create_edge(qwen_id, asgard_rebirth_id, "REVIEWS", {"phases": ["P1", "P2", "P3"]})

# Framework and architecture relationships
create_edge(memos_id, fastmcp_id, "BUILT_WITH", {"framework_usage": "Core Service Implementation"})
create_edge(memos_id, three_layer_arch_id, "IMPLEMENTS", {"architectural_pattern": True})
create_edge(memos_id, pluggable_storage_id, "IMPLEMENTS", {"storage_design": "Four-tier"})

# Standards usage
create_edge(taskmaster_protocol_id, poml_id, "USES", {"format": "Machine-readable tasks"})
create_edge(apexsigma_org_id, poml_id, "STANDARDIZES_ON", {"scope": "Knowledge formatting"})

# Cross-service dependencies
create_edge(adep_sprint1_id, omega_ingest_laws_id, "COMPLIES_WITH", {"integration": "Knowledge graph pipeline"})
create_edge(mar_protocol_id, omega_ingest_laws_id, "ENFORCES", {"verification": "Dual verification requirement"})

# Verification relationships
create_edge(omega_ingest_laws_id, neo4j_id, "PROTECTS", {"monitoring": "24/7", "constraints": "Unauthorized modification prevention"})
create_edge(omega_ingest_laws_id, postgresql_id, "PROTECTS", {"monitoring": "24/7", "health_checks": "Every 30 seconds"})

print(f"Created relationships between entities")

# Update metadata with final counts
consolidated_kg["knowledgeGraph"]["metadata"]["sourceGraphCount"] = len(set([
    "AGENT.md", "OMEGA_INGEST_LAWS.md", "The_ApexSigma_Glossary_v1.0.md", 
    "Services-Tree.md", "Operation_Monorepo_Genesis_Final_Completion_Report.md",
    "Operation-Asgard-Rebirth-memOS-MCP-Upgrade-Plan-v5.md", "sprint_1_backlog.md", 
    "asgard_roadmap.md", "The_Laws_of_Asgard_A_Primer_for_Agents_of_the_ApexSigma_Ecosystem.md"
]))
consolidated_kg["knowledgeGraph"]["metadata"]["totalNodes"] = len(consolidated_kg["knowledgeGraph"]["nodes"])
consolidated_kg["knowledgeGraph"]["metadata"]["totalEdges"] = len(consolidated_kg["knowledgeGraph"]["edges"])

print(f"\n=== CONSOLIDATION SUMMARY ===")
print(f"Source Graphs Processed: {consolidated_kg['knowledgeGraph']['metadata']['sourceGraphCount']}")
print(f"Total Nodes Created: {consolidated_kg['knowledgeGraph']['metadata']['totalNodes']}")  
print(f"Total Edges Created: {consolidated_kg['knowledgeGraph']['metadata']['totalEdges']}")
print(f"Consolidation Date: {consolidated_kg['knowledgeGraph']['metadata']['consolidationDate']}")