# Continue building the knowledge graph with core services and protocols

# 4. Core Services in the ApexSigma Ecosystem
memos_id = create_node(
    "memOS.as",
    "Service",
    {
        "description": "Core memory service providing multi-tiered, pluggable storage architecture",
        "architecture": "Four-tier storage design",
        "tiers": [
            "Redis cache",
            "PostgreSQL metadata", 
            "Qdrant semantic recall",
            "Neo4j episodic memory"
        ],
        "status": "Active Development",
        "api_endpoint": "172.26.0.13:8090"
    },
    source_ids=["The_ApexSigma_Glossary_v1.0.md", "Services-Tree.md"],
    created_date="2025-08-31T00:00:00Z"
)

ingest_llm_id = create_node(
    "InGest-LLM.as", 
    "Service",
    {
        "description": "Ingestion gateway service for processing and ingesting data",
        "api_endpoint": "172.26.0.12:8000",
        "status": "Active",
        "role": "Data ingestion and processing pipeline"
    },
    source_ids=["Services-Tree.md", "OMEGA_INGEST_LAWS.md"],
    created_date="2025-08-31T00:00:00Z"
)

devenviro_id = create_node(
    "devenviro.as",
    "Service", 
    {
        "description": "Development environment orchestrator service",
        "status": "Active",
        "role": "Agent database and orchestration"
    },
    source_ids=["Services-Tree.md"],
    created_date="2025-08-31T00:00:00Z"
)

tools_id = create_node(
    "tools.as",
    "Service",
    {
        "description": "Tools and utilities service registry",
        "status": "Active",
        "role": "Service registry and tool management"
    },
    source_ids=["Services-Tree.md"],
    created_date="2025-08-31T00:00:00Z"
)

# 5. Core Protocols and Laws
omega_ingest_laws_id = create_node(
    "Omega Ingest Laws",
    "Protocol",
    {
        "description": "Immutable Truth Protocol governing master knowledge graph",
        "authority": "ApexSigma Ecosystem Governance",
        "status": "ACTIVE ENFORCEMENT",
        "established_date": "2025-08-31",
        "fundamental_principles": [
            "Single Source of Truth",
            "Immutability of Verified Data", 
            "Dual Verification Requirement"
        ],
        "violation_consequences": "Immediate system lock, dual verification reset required"
    },
    source_ids=["OMEGA_INGEST_LAWS.md", "The_Laws_of_Asgard_A_Primer_for_Agents_of_the_ApexSigma_Ecosystem.md"],
    created_date="2025-08-31T00:00:00Z"
)

mar_protocol_id = create_node(
    "MAR Protocol (Mandatory Agent Review)",
    "Protocol",
    {
        "description": "Mandatory quality gatekeeper workflow requiring formal approval before task completion",
        "type": "Quality Gate",
        "requirements": [
            "All implementations must receive Gemini review before deployment",
            "No code changes deploy to Alpha branch without MAR approval",
            "Review checklist must be completed for each task"
        ],
        "process_steps": [
            "Implementer completes task and requests review",
            "Gemini conducts comprehensive evaluation", 
            "Gemini provides approval or requests modifications",
            "Only after approval can task be marked complete"
        ]
    },
    source_ids=["AGENT.md", "The_Laws_of_Asgard_A_Primer_for_Agents_of_the_ApexSigma_Ecosystem.md"],
    created_date="2025-09-18T00:00:00Z"
)

taskmaster_protocol_id = create_node(
    "TaskMaster MCP Framework",
    "Protocol",
    {
        "description": "Autonomous agent framework for structured task orchestration", 
        "requirements": [
            "Every major project requires formal MCP document",
            "MCPs must define clear phases, tasks, roles, and success criteria",
            "All agents must follow MCP structure for consistency"
        ],
        "output_format": "Dual-output: Markdown for humans, POML for machines",
        "mandatory_elements": ["Implementer role", "Reviewer role", "Done means Done criteria"]
    },
    source_ids=["AGENT.md", "The_ApexSigma_Glossary_v1.0.md"],
    created_date="2025-09-18T00:00:00Z"
)

# 6. Knowledge Graph Infrastructure  
neo4j_id = create_node(
    "Neo4j Knowledge Graph",
    "Database",
    {
        "description": "Master knowledge graph storing Omega Ingest data",
        "endpoint": "172.26.0.14:7687", 
        "role": "Concept relationships and episodic memory storage",
        "status": "Protected Service - 24/7 Monitoring Required"
    },
    source_ids=["OMEGA_INGEST_LAWS.md"],
    created_date="2025-08-31T00:00:00Z"
)

postgresql_id = create_node(
    "PostgreSQL Main",
    "Database",
    {
        "description": "Primary relational database for procedural memory",
        "endpoint": "172.26.0.2:5432",
        "role": "Procedural memory and metadata storage", 
        "status": "Protected Service - 24/7 Monitoring Required"
    },
    source_ids=["OMEGA_INGEST_LAWS.md"],
    created_date="2025-08-31T00:00:00Z"
)

print(f"Created core services, protocols, and infrastructure nodes")