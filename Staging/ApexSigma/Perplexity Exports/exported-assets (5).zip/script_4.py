# Validate the knowledge graph structure and perform integrity checks
print("=== INTEGRITY VALIDATION ===")

# Check for orphaned nodes (nodes with no relationships)
node_ids = {node["id"] for node in consolidated_kg["knowledgeGraph"]["nodes"]}
connected_nodes = set()

for edge in consolidated_kg["knowledgeGraph"]["edges"]:
    connected_nodes.add(edge["source"])
    connected_nodes.add(edge["target"])

orphaned_nodes = node_ids - connected_nodes
if orphaned_nodes:
    print(f"WARNING: Found {len(orphaned_nodes)} orphaned nodes: {list(orphaned_nodes)}")
else:
    print("✓ No orphaned nodes found - all entities have relationships")

# Check for invalid edge references
invalid_edges = []
for edge in consolidated_kg["knowledgeGraph"]["edges"]:
    if edge["source"] not in node_ids:
        invalid_edges.append(f"Edge {edge['id']} references invalid source: {edge['source']}")
    if edge["target"] not in node_ids:
        invalid_edges.append(f"Edge {edge['id']} references invalid target: {edge['target']}")

if invalid_edges:
    print(f"ERROR: Found {len(invalid_edges)} invalid edge references:")
    for error in invalid_edges:
        print(f"  - {error}")
else:
    print("✓ All edge references are valid")

# Check for duplicate node IDs
node_id_counts = {}
for node in consolidated_kg["knowledgeGraph"]["nodes"]:
    node_id = node["id"]
    node_id_counts[node_id] = node_id_counts.get(node_id, 0) + 1

duplicate_ids = {nid: count for nid, count in node_id_counts.items() if count > 1}
if duplicate_ids:
    print(f"ERROR: Found duplicate node IDs: {duplicate_ids}")
else:
    print("✓ All node IDs are unique")

# Validate required schema fields
schema_errors = []
for node in consolidated_kg["knowledgeGraph"]["nodes"]:
    required_fields = ["id", "label", "type", "properties", "timestamps", "source_ids"]
    for field in required_fields:
        if field not in node:
            schema_errors.append(f"Node {node.get('id', 'UNKNOWN')} missing required field: {field}")
    
    if "timestamps" in node:
        timestamp_fields = ["createdAt", "lastModified"]
        for ts_field in timestamp_fields:
            if ts_field not in node["timestamps"]:
                schema_errors.append(f"Node {node['id']} missing timestamp field: {ts_field}")

for edge in consolidated_kg["knowledgeGraph"]["edges"]:
    required_fields = ["id", "source", "target", "label", "properties", "timestamps"]
    for field in required_fields:
        if field not in edge:
            schema_errors.append(f"Edge {edge.get('id', 'UNKNOWN')} missing required field: {field}")

if schema_errors:
    print(f"ERROR: Found {len(schema_errors)} schema validation errors:")
    for error in schema_errors[:5]:  # Show first 5 errors
        print(f"  - {error}")
    if len(schema_errors) > 5:
        print(f"  ... and {len(schema_errors) - 5} more")
else:
    print("✓ Schema validation passed")

print("\n=== KNOWLEDGE GRAPH STATISTICS ===")

# Entity type distribution
entity_types = {}
for node in consolidated_kg["knowledgeGraph"]["nodes"]:
    node_type = node["type"]
    entity_types[node_type] = entity_types.get(node_type, 0) + 1

print("Node Distribution by Type:")
for node_type, count in sorted(entity_types.items()):
    print(f"  {node_type}: {count}")

# Relationship type distribution  
relationship_types = {}
for edge in consolidated_kg["knowledgeGraph"]["edges"]:
    rel_type = edge["label"]
    relationship_types[rel_type] = relationship_types.get(rel_type, 0) + 1

print("\nRelationship Distribution by Type:")
for rel_type, count in sorted(relationship_types.items()):
    print(f"  {rel_type}: {count}")

# Source file coverage
source_files = set()
for node in consolidated_kg["knowledgeGraph"]["nodes"]:
    source_files.update(node.get("source_ids", []))

print(f"\nSource File Coverage: {len(source_files)} files")
for source_file in sorted(source_files):
    print(f"  - {source_file}")

print("\n✓ Integrity validation completed successfully")
print("✓ Knowledge graph is semantically coherent and ready for serialization")